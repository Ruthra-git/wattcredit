# wattcredit — 4-layer mains power-monitor PCB (KiCad 9)

Open `wattcredit.kicad_pro` in KiCad 9.0.x. Board: **125 × 100 mm, 4 layers, 1.6 mm, 2 oz outer / 1 oz-class inner (0.035 mm)**, ENIG.

> **This board connects to mains. It has been checked by KiCad DRC and a schematic-parity check only. It has NOT been reviewed against IEC 62368-1 / 61010-1, has not been built, and has not been tested. Have a qualified person review creepage/clearance, fusing and enclosure before any live use.**

## Files
| Path | What |
|---|---|
| `wattcredit.kicad_pcb / .kicad_pro / .kicad_dru` | Board, project (net classes, stackup), custom isolation rules |
| `wattcredit.kicad_sch`, `ESP32.kicad_sch` | **Corrected** schematics (your originals are untouched in your upload) |
| `fab/`, `wattcredit_gerbers.zip` | Gerbers (4 Cu, mask, paste, silk, edge) + Excellon drills |
| `docs/DRC_report.rpt`, `ERC_report.rpt`, `BOM.csv`, `wattcredit_layers.pdf`, `images/` | Reports and renders |

## Verification status (all run with real KiCad 9.0.3 `kicad-cli`)
* **DRC: 0 errors, 0 unconnected items, 0 footprint errors.** 4 warnings remain, all silkscreen (2 = ESP32 module outline touches the board edge, by design for the antenna end).
* **Schematic parity: clean** — every net, footprint and value on the PCB matches the corrected schematics. "Update PCB from Schematic" should report no changes.
* Custom rules enforced (see `.kicad_dru`): **HV↔LV ≥ 6.0 mm**, mains nets (L/N/PE) to anything ≥ **2.4 mm**.
* **Not verified:** nothing was opened in the KiCad GUI; no 3D check; no thermal test; no creepage-over-surface analysis (KiCad only checks air clearance).

## Schematic corrections I made (needed before a PCB was meaningful)
Verified by exporting the netlist before/after; nothing else moved.

| # | Problem in the original | Fix |
|---|---|---|
| 1 | A stray wire tied **both AMC1100 INN + GND1 pins to the logic +5 V rail** — shorts the isolation barrier | Wire removed |
| 2 | Isolated-side references (U1/U2 GND1/INN, CB4/CB5 return, DC-DC −Vout) were on logic GND / mains neutral | Now one mains-side "Kelvin island" `GND_ISO` |
| 3 | The 4-wire shunt's Kelvin pad R2.2 and the divider bottom R5.2 shared the 10 A neutral path | Separated: power neutral (`FORCE_IN`) vs Kelvin island (`GND_ISO`) — a ~12 mV drop at 10 A would otherwise corrupt the 50 mV signal |
| 4 | Shunt pins 3/4 swapped (pin 3 = sense pad, pin 4 = big force pad on the real footprint) — 10 A would run through a 1.4 × 0.76 mm pad | Swapped |
| 5 | AMS1117 input fed from the *isolated* 5 V_ISO | Now from `+5v_LOGIC` |
| 6 | MCP3422 CH2 inputs both on `ADC_I_N`; `ADC_V_P/N` never connected | CH2 → `ADC_V_P` / `ADC_V_N` |
| 7 | `mcu_boot` on GPIO3 (JTAG strap) instead of GPIO0 | → GPIO0 (U3 pin 27) |
| 8 | `PWR_FAIL` was a *local* label in the sub-sheet → never joined the root sheet | Made global |
| 9 | **Footprints:** 10 A fuse in 0603, 5 mΩ shunt in 01005, 330 kΩ HV resistors in 01005/0402, mains terminals at 1.27 mm pitch, MOV as a 0508 resistor, LED symbol on a 6-pad APA102 footprint, programming header on a DIN41612, battery clip with no GND pad, etc. | 5×20 fuse clips, WSK2512 4-terminal shunt, 1206 HV resistors, 5.08 mm MKDS 3-pole terminals, 12 mm disc MOV, 0603 LED, 1×6 header, CR2032 holder (Keystone 3034) … see `BOM.csv` |
| 10 | **Layout-driven:** J2 pins 1 and 3 swapped (**J2: pin 1 = PE, pin 3 = L**) so L/N/PE line up with J1 and no 10 A net crosses another | Silkscreen marks L / N / PE — please check this against any harness you already planned |

## Layout summary
* **Left = mains zone, right = low-voltage.** AMC1100 ×2, HLK-PM01 and the isolated DC-DC straddle the barrier; AMC1100 pad gap is 8.85 mm.
* 10 A path: 2.5 mm tracks on 2 oz outer copper (≈ 18 °C rise by IPC-2221 external-trace estimate). L/N on F.Cu, PE on B.Cu. MOV stubs are 2.5 mm (surge).
* Kelvin sense pair routed as thin tracks from the shunt's sense pads, using layer hops under the neutral trace.
* In1 = solid GND (LV side), In2 = 3V3 plane, signals on F.Cu/B.Cu; mains zone has no copper on inner layers except two sense signals.
* ESP32-S3 module at the top edge, antenna keepout (15 mm sides) respected; nothing under the antenna.
* LV/signal routing was done with Freerouting, not by hand: it is functional and DRC-clean but not hand-polished (some long 45° runs, e.g. I²C near the RTC).

## Open items — need your decision (I did not change these)
1. **Wire-entry direction of the MKDS terminals** was assumed (entry facing the board edge). Verify in the 3D viewer.
2. **Fuse holder / MOV / fuse ratings:** the Littelfuse 111 clip and 12 mm disc MOV are placeholders consistent with "10 A, 275 VAC"; confirm part ratings (UL/VDE) and pick the real MOV energy rating.
3. **Isolation ratings:** CRE1 DC-DC pad-to-pad gap is only 6.1 mm (vs 8.85 mm on the AMC1100). Confirm its working-voltage / reinforced rating, or mill a slot between its pin rows. HLK-PM01 AC↔DC pins are 29 mm apart (fine).
4. **Supervisors are not functional as drawn:** `power_supervisor1` has SENSE/MR/CT unconnected and `RESET` (open-drain) has no pull-up; U7 has RESET unconnected and SENSE tied to `PWR_FAIL`. Decide the intended function.
5. **AMS1117-3.3** is unstable with a pure low-ESR ceramic output cap (CB2 = 22 µF): use tantalum or add ESR. **CS1** has no value ("C"). **BT1** value says "5V" (a CR2032 is 3 V).
6. ESP32 USB D± (GPIO19/20) are unconnected; IO3 now NC.
7. ERC leftovers: 3 "power pin not driven" (AC-DC L/N, RTC VBAT) → add PWR_FLAG symbols; benign naming warnings (`GND_ISO`/`SH_SENSE_IN`, `FORCE_IN`/`N_IN`).
8. Mounting holes exist only on the LV side. For a mains enclosure add mounting that respects creepage, and consider a milled slot along the barrier.
9. Fab: order **2 oz outer copper** with 4-layer ENIG; vias are 0.35 mm drill (ESP32 thermal pad uses 0.2 mm per its footprint).
